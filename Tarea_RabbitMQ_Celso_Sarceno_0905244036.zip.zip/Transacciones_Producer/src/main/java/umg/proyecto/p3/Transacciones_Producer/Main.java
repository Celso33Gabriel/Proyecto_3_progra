package umg.proyecto.p3.Transacciones_Producer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.universidad.proyecto.model.LoteTransacciones;
import com.universidad.proyecto.model.Transaccion;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

public class Main {

    public static void main(String[] args) {
      
        String urlApi = "https://hly784ig9d.execute-api.us-east-1.amazonaws.com/default/transacciones"; 

        try {
            System.out.println("Conectando a la API...");
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlApi))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                System.out.println("Error: La API respondió con código " + response.statusCode());
                return;
            }

            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule()); 
            
            LoteTransacciones lote = mapper.readValue(response.body(), LoteTransacciones.class);
            System.out.println("Lote " + lote.getLoteId() + " recibido con " + lote.getTransacciones().size() + " transacciones.");
            
            enviarTransaccionesARabbit(lote);

        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void enviarTransaccionesARabbit(LoteTransacciones lote) {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost"); 

        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {

            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());

            for (Transaccion tx : lote.getTransacciones()) {
                
               
                if (tx.getDetalle() != null) {
                    String Nombre = "Celso Gabriel Sarceño Corado"; 
                    String Carnet = "0905-24-4036"; 
                    String Correo = "csarcenoc1@miumg.edu.gt";
                    String firma = "Alumno: " + Nombre + " | Carnet: " + Carnet + "| Correo: " + Correo;
                    tx.getDetalle().setDescripcion(firma + " | " + tx.getDetalle().getDescripcion());
                }
               

                String nombreCola = tx.getBancoDestino(); 
                channel.queueDeclare(nombreCola, true, false, false, null);
                
                String mensajeJson = mapper.writeValueAsString(tx);

                channel.basicPublish("", nombreCola, null, mensajeJson.getBytes(StandardCharsets.UTF_8));
                
                System.out.println(" [✔] Enviada TX " + tx.getIdTransaccion() + " a cola: " + nombreCola);
            }
            
            System.out.println("\n--- Proceso finalizado correctamente ---");

        } catch (Exception e) {
            System.err.println("Error enviando a RabbitMQ: " + e.getMessage());
        }
    }
}
